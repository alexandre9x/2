
<html>

    <head>

        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link href="bootstrap.css" rel="stylesheet" type="text/css">

        <link href="animate.css" rel="stylesheet" type="text/css">

        <link href="king.css" rel="stylesheet" type="text/css">

        <style>

            textarea.form-control {

                font-family: sans-serif;

                text-align: center;

            }

            div.cc {

                font-family: sans-serif;

            }

            div.polaroid {

                width: 250px;

                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);

                text-align: center;

            }

            div.container {

                padding: 10px;

            }

        </style>

        <link rel="shortcut icon" type="image/icon" href="icon.jpg">

        <title>#BestChecker</title>

    </head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript">


        function pushPaypalDie(str) {

            document.getElementById('reprovadas').innerHTML += '<div>' + str + '</div>';

        }

        function pushPaypal(str) {

            document.getElementById('aprovadas').innerHTML += '<div>' + str + '</div>';

        }



    </script>


    <script title="ajax do checker">
            $(document).ready(function () {
                $('#testar').click(function () {
                    var line = $('#lista').val().replace(',', '').split('\n');
                    line = line.filter(function (item, index, inputArray) {
                        return inputArray.indexOf(item) == index;
                    });
                    $("#lista").val(line.join("\n"));
                    line.forEach(function (value) {
                        var ajaxCall = $.ajax({
                            url: 'includes/api_nova.php',
                            type: 'GET',
                            data: 'lista=' + value,
                            success: function (data) {
                                var status = data.includes("Aprovado");
                                var statussocks = data.includes("SOCKSRUIM");
                                if (status) {
                                    removelinha();
                                    document.getElementById("aprovadas").innerHTML += data + "<br>";
                                } else if (statussocks) {
                                    removelinha();
                                    document.getElementById("sksdies").innerHTML += data + "<br>";
                                } else {
                                    removelinha();
                                    document.getElementById("reprovadas").innerHTML += data + "<br>";
                                }
                            }
                        });
                    });

                });
            });
        function removelinha() {
            var lines = $("#lista").val().split('\n');
            lines.splice(0, 1);
            $("#lista").val(lines.join("\n"));
        }
    </script>


    <body>

        <div class="animated bounceInDown" id="formulario">

            <center><div class="pane equal" style="width: 800px; text-align:left; margin: 10px;">

                    <center><span style="font-size:20px;">[ Best-Checker - Mercado Livre ]</span><br><br>
                    <center><span style="font-size:18px;">[ Discord => zBest#7537 ]</span><br><br>
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#acoes">Ações</a></li>
                            <li><a href="#status">Status / Contadores</a></li>
                            <li><a href="#infos">Informações adicionais</a></li>
                        </ul>


                        <center>


                            <div id="acoes">
                                <textarea name="lista" placeholder="email@localhost.com|123456" class="form-control" id="lista" style="width: 300%; height: 150;" placeholder=""></textarea> <br>
                      
                            </div>
                            <br>

                            <br>
                            <button type="submit" name="testar" id="testar" value="Iniciar"  style="width:45%;" class="fcbtn btn btn-success btn-outline btn-1e"><span aria-hidden="true"></span> Iniciar</button> <button type="submit" name="testar" id="testar" value="Parar"  style="width:45%;" class="fcbtn btn btn-danger btn-outline btn-1e">Parar</button>


                            <br><br>

                            </div>


                            <center><div class="panel panel-success" style="width: 1300; margin: 10px; font-family: 'Poppins', sans-serif !important;">

                                    <div class="panel-heading"> Lives</div>

                                    <div id="aprovadas" name="aprovadas" class="panel-body">


                                    </div>

                                </div>

                                <center>

                                    <div class="panel panel-danger" style="width: 1000; margin: 10px;">

                                        <div class="panel-heading"> Dies</div>
                                        <div id="reprovadas" name="reprovadas" class="panel-body">

                                        </div>

                                    </div>

                                    <div class="panel panel-warning" style="width: 700; margin: 10px;">

                                        <div class="panel-heading"> Socks Dies</div>
                                        <div id="sksdies" name="sksdies" class="panel-body">

                                        </div>

                                    </div>

                                <center>



                                </center></center></center></div></body></html>
